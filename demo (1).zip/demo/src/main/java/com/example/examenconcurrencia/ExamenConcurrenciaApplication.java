package com.example.examenconcurrencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenConcurrenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenConcurrenciaApplication.class, args);
	}

}
