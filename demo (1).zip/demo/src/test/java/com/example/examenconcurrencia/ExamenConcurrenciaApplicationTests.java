package com.example.examenconcurrencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenConcurrenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
